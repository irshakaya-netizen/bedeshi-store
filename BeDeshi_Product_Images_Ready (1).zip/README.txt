Beদেশী product image update

Upload index.html to the root of your GitHub repository, replacing the previous index.html.
The product photos are loaded from public image URLs hosted by brand/retailer websites, so an image may stop loading if its source website changes access.
